# frozen_string_literal: true

module Arel # :nodoc: all
  module Nodes
    class In < Equality
    end
  end
end
