# frozen_string_literal: true

require "active_record/type_caster/map"
require "active_record/type_caster/connection"

module ActiveRecord
  module TypeCaster # :nodoc:
  end
end
