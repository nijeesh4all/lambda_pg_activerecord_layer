# frozen_string_literal: true

module Zeitwerk
  VERSION = "2.3.0"
end
