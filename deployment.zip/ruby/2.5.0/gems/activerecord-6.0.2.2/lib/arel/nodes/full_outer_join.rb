# frozen_string_literal: true

module Arel # :nodoc: all
  module Nodes
    class FullOuterJoin < Arel::Nodes::Join
    end
  end
end
