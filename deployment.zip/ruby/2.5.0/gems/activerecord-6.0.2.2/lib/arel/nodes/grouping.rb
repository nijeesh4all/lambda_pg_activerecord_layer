# frozen_string_literal: true

module Arel # :nodoc: all
  module Nodes
    class Grouping < Unary
    end
  end
end
