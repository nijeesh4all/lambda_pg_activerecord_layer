# frozen_string_literal: true

module Arel # :nodoc: all
  module Nodes
    class OuterJoin < Arel::Nodes::Join
    end
  end
end
