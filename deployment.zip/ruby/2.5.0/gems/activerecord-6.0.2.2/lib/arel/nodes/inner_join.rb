# frozen_string_literal: true

module Arel # :nodoc: all
  module Nodes
    class InnerJoin < Arel::Nodes::Join
    end
  end
end
