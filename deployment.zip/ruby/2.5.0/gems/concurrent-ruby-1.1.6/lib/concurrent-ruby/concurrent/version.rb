module Concurrent
  VERSION      = '1.1.6'
end
